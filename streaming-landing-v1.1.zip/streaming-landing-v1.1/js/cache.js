async function loadCSV(url) {
  const cached = localStorage.getItem(url);
  if (cached) return JSON.parse(cached);

  return new Promise(resolve => {
    Papa.parse(url, {
      download: true,
      header: true,
      complete: res => {
        localStorage.setItem(url, JSON.stringify(res.data));
        resolve(res.data);
      }
    });
  });
}
