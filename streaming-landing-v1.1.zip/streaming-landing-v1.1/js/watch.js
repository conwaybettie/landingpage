const id = new URLSearchParams(location.search).get("id");

if (!id) {
  document.body.innerHTML = "<h2>Video tidak ditemukan</h2>";
}

Papa.parse("../data/videos.csv", {
  download: true,
  header: true,
  complete: function(results) {
    const v = results.data.find(x => x.id === id);
    if (!v) {
      document.body.innerHTML = "<h2>Video tidak ditemukan</h2>";
      return;
    }

    const video = document.querySelector("video");
    video.src = v.video_url;
    video.preload = "metadata";

    document.querySelector("h1").textContent = v.title;
    document.querySelector(".desc").textContent = v.description;

    // SEO title dinamis
    document.title = v.title + " | My Streaming";
  }
});
const meta = (p, c) => {
  const m = document.createElement("meta");
  m.setAttribute("property", p);
  m.content = c;
  document.head.appendChild(m);
};

meta("og:title", v.title);
meta("og:description", v.description);
meta("og:image", v.thumbnail);
meta("og:type", "video.other");