fetch("data/ads.json")
  .then(res => res.json())
  .then(data => {
    document.querySelectorAll("[data-ad]").forEach(slot => {
      const pos = slot.dataset.ad;
      if (!data[pos]) return;

      data[pos].forEach(ad => {
        slot.innerHTML += ad.html;
      });
    });
  });
