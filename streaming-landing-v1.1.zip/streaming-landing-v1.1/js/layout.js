async function loadComponent(selector, file) {
  const el = document.querySelector(selector);
  if (!el) return;

  const res = await fetch(file);
  el.innerHTML = await res.text();
}

loadComponent("#header", "components/header.html");
loadComponent("#footer", "components/footer.html");
