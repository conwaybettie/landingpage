var _Hasync = _Hasync || [];
_Hasync.push(['Histats.start', '1,4965497,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);

(function() {
  var hs = document.createElement('script');
  hs.type = 'text/javascript';
  hs.async = true;
  hs.src = (location.protocol === 'https:' ? 'https://' : 'http://') + 's10.histats.com/js15_as.js';
  document.head.appendChild(hs);
})();
