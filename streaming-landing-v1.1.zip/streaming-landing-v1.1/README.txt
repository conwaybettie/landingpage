THEME NAME : Streaming Landing Page
VERSION    : v1.1
TYPE       : Static HTML Theme

INSTALLATION
1. Upload all files to your hosting root
2. Make sure /data/videos.csv exists
3. Open index.html

ADDING VIDEOS
- Open /data/videos.csv
- Each row = 1 video
- ID must be unique

IMPORTANT
- Do not edit HTML to add videos
- Do not remove histats.js
- Use real domain (not localhost) for ads & analytics

REQUIREMENTS
- Hosting with static file support
- HTTPS recommended

AUTHOR
- Custom Streaming Theme

